import * as flsFunctions from "./modules/functions.js";
import "./modules/swiper.js";

flsFunctions.isWebp();

/*
import Swiper, { Navigation, Pagination } from 'swiper';
const swiper = new Swiper();
*/